#!/usr/bin/env python3
# Script to f3tch t3h fl4gz0rx

import os
import base64
import json
from Crypto.Cipher import AES
from Crypto.Util import number
from Crypto.Protocol.KDF import scrypt

AES_BLOCK_SIZE = 32
AES_KEY_SIZE = 32


def get_aes_key(shared_num, salt):
    bnum = shared_num.to_bytes((shared_num.bit_length() + 7) // 8, byteorder='big')
    return scrypt(bnum, salt, AES_BLOCK_SIZE, N=2**14, r=8, p=1)

def decrypt_aes(msg, key):
    pass # TODO you should be able to easily figure out the mode


if __name__ == "__main__":
    pass  # TODO: so it begins...

