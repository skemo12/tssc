#!/usr/bin/python3

import crypt


password = # TODO(1)

salt = # TODO(2)

hash = # TODO(3)

print(hash)
